def figure_values(figure):
  figure_values = {
    'redonda': 1, 'blanca': 2, 'negra': 4, 'corchea': 8,
    'semicorchea': 16, 'fusa': 32, 'semifusa': 64
  }

  return figure_values[figure]
